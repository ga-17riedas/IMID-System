create definer = root@localhost trigger update_patient_age_update
    before update
    on patients
    for each row
BEGIN
    IF NEW.birth_date != OLD.birth_date OR NEW.age IS NULL THEN
        SET NEW.age = TIMESTAMPDIFF(YEAR, NEW.birth_date, CURDATE());
    END IF;
END;


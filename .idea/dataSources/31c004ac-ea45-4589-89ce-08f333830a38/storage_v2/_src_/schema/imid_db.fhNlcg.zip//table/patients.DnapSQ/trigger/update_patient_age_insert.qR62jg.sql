create definer = root@localhost trigger update_patient_age_insert
    before insert
    on patients
    for each row
BEGIN
    SET NEW.age = TIMESTAMPDIFF(YEAR, NEW.birth_date, CURDATE());
END;

